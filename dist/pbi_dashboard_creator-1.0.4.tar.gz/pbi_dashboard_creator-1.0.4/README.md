# PBI-dashboard-creator
This is a python module that can be used to automatically create PowerBI dashboards using the .pbir file type
