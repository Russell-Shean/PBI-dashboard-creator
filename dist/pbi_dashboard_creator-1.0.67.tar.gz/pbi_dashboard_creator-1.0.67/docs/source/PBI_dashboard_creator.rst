PBI\_dashboard\_creator package
===============================

Submodules
----------

PBI\_dashboard\_creator.add\_ADLS\_csv module
---------------------------------------------

.. automodule:: PBI_dashboard_creator.add_ADLS_csv
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_background\_image module
-----------------------------------------------------

.. automodule:: PBI_dashboard_creator.add_background_image
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_button module
------------------------------------------

.. automodule:: PBI_dashboard_creator.add_button
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_local\_csv module
----------------------------------------------

.. automodule:: PBI_dashboard_creator.add_local_csv
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_shape\_map module
----------------------------------------------

.. automodule:: PBI_dashboard_creator.add_shape_map
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_text\_box module
---------------------------------------------

.. automodule:: PBI_dashboard_creator.add_text_box
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.add\_tmdl module
----------------------------------------

.. automodule:: PBI_dashboard_creator.add_tmdl
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.create\_blank\_dashboard module
-------------------------------------------------------

.. automodule:: PBI_dashboard_creator.create_blank_dashboard
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.create\_date\_hrcy module
-------------------------------------------------

.. automodule:: PBI_dashboard_creator.create_date_hrcy
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.create\_new\_chart module
-------------------------------------------------

.. automodule:: PBI_dashboard_creator.create_new_chart
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.create\_new\_page module
------------------------------------------------

.. automodule:: PBI_dashboard_creator.create_new_page
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.create\_tmdl module
-------------------------------------------

.. automodule:: PBI_dashboard_creator.create_tmdl
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.update\_diagramLayout module
----------------------------------------------------

.. automodule:: PBI_dashboard_creator.update_diagramLayout
   :members:
   :undoc-members:
   :show-inheritance:

PBI\_dashboard\_creator.update\_model\_file module
--------------------------------------------------

.. automodule:: PBI_dashboard_creator.update_model_file
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: PBI_dashboard_creator
   :members:
   :undoc-members:
   :show-inheritance:
