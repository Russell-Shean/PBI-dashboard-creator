import os
import sys

test_path = sys.path.insert(0, os.path.abspath("../PBI_dashboard_creator/src/PBI_dashboard_creator/"))

print(os.path.abspath("../PBI_dashboard_creator/src/PBI_dashboard_creator/"))

print(sys.path)
