.. PBI_dashboard_creator documentation master file, created by
   sphinx-quickstart on Mon Feb  3 11:58:05 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PBI_dashboard_creator documentation
===================================

Here's the documentation built automatically from function docstrings


.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   intro
   PBI_dashboard_creator
   examples

.. automodule:: PBI_dashboard_creator
   :members:
   :undoc-members:
   :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

